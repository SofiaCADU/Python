#Sofía Cáceres
#Me gusta ver las estrellas
#17/03/2025

Mascotas = ["Perros","Gatos","peces","pajaros","tortugas"]
print(Mascotas[3])

Mascotas[-1] = ("Cuyis")
print(Mascotas)

Mascotas.append("Caballos")
print(Mascotas)

Mascotas.insert(2,"Hamsters")
print(Mascotas)

eliminado = Mascotas.pop(3)
print(Mascotas)

indice = Mascotas.index("pajaros")
print(indice)

Mascotas.sort()
print(Mascotas)

Mascotas.reverse()
print(Mascotas)